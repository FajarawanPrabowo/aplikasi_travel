<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Agent extends CI_Controller {
	
	var $folder =   "main/agent";
    var $title  =   "Data agent";

	function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('Model_agent','agent');
	}

	function index(){
		cek_session_admin();
		
	   	$data ['title']	= $this->title;	   	
		$this->template->load('template',$this->folder.'/agent',$data);
	}

	function tgl_to_sql($date){
	$exp = explode('-',$date);
		if(count($exp) == 3) {
			$date = $exp[2].'-'.$exp[1].'-'.$exp[0];
		}
		return $date;
	}

	function edit($id = NULL){
		cek_session_admin();
		if (isset($_POST['submit'])){
		$data = array(
				'nama_agent' => $this->input->post('nama_agent'),
				'aktif' => $this->input->post('aktif'),
			);

	  	$this->agent->update(array('id_agent' => $this->input->post('id_agent')), $data);
	  	$this->session->set_flashdata('success',' Edit Data Agent');
	  	redirect('agent');
		}else{
		if ($id == NULL){
			redirect('agent');
		}
		$data ['title']	= $this->title;
		$data ['record']= $this->agent->get_by_id_md5($id);
		$this->template->load('template',$this->folder.'/edit',$data);	
		}
		
	}

	function detail($id){
		if ($id == NULL){
			redirect('reservasi');
		}
		$data ['title']	= $this->title;
		$data ['record']= $this->reservasi->get_by_id_md5($id);
		$this->template->load('template',$this->folder.'/detail',$data);	
	}

	function tambah(){
		cek_session_admin();
		if (isset($_POST['submit'])){
	   	$data = array(
				'nama_agent' => $this->input->post('nama_agent')
			);

	  	$insert = $this->agent->save($data);
	  	$this->session->set_flashdata('success',' Tambah Data Agent');
	  	redirect('agent');
		}else{
		$data ['title']	= $this->title;
		$this->template->load('template',$this->folder.'/tambah',$data);		
		}
	}

	function getdata()
	{
		cek_session_admin();
		$list = $this->agent->get_datatables();
		$data = array();
		$no = $_POST['start'];
		
		foreach ($list as $field) {
			
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $field->nama_agent;
			$row[] = $field->aktif;
			//add html for action
			$row[] = '<a class="btn  btn-xs btn-default" href="'.base_url()."agent/edit/".md5($field->id_agent).'" title="Edit" ><i class="fa fa-pencil"></i></a>
				  <a class="btn btn-xs btn-danger" href="javascript:void(0)" title="Hapus" onclick="hapus('."'".$field->id_agent."'".')"><i class="glyphicon glyphicon-trash"></i> </a>';

			$data[] = $row;
		}

		$output = array(
			"draw" => $_POST['draw'],
			"recordsTotal" => $this->agent->count_all(),
			"recordsFiltered" => $this->agent->count_filtered(),
			"data" => $data,
		);
		//output dalam format JSON
		echo json_encode($output);
	}


	public function hapus($id)
	{
		cek_session_admin();
		$this->agent->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}



}
