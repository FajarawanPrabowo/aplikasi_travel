<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Carrier extends CI_Controller {
	
	var $folder =   "main/carrier";
    var $title  =   "Data Carrier";

	function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('Model_carrier','carrier');
	}

	function index(){
		cek_session_admin();
		
	   	$data ['title']	= $this->title;	   	
		$this->template->load('template',$this->folder.'/carrier',$data);
	}

	function tgl_to_sql($date){
	$exp = explode('-',$date);
		if(count($exp) == 3) {
			$date = $exp[2].'-'.$exp[1].'-'.$exp[0];
		}
		return $date;
	}

	function edit($id = NULL){
		cek_session_admin();
		if (isset($_POST['submit'])){
		$data = array(
				'nama_carrier' => $this->input->post('nama_carrier'),
				'aktif' => $this->input->post('aktif'),
			);

	  	$this->carrier->update(array('id_carrier' => $this->input->post('id_carrier')), $data);
	  	$this->session->set_flashdata('success',' Edit Data Carrier');
	  	redirect('carrier');
		}else{
		if ($id == NULL){
			redirect('carrier');
		}
		$data ['title']	= $this->title;
		$data ['record']= $this->carrier->get_by_id_md5($id);
		$this->template->load('template',$this->folder.'/edit',$data);	
		}
		
	}

	function detail($id){
		if ($id == NULL){
			redirect('reservasi');
		}
		$data ['title']	= $this->title;
		$data ['record']= $this->reservasi->get_by_id_md5($id);
		$this->template->load('template',$this->folder.'/detail',$data);	
	}

	function tambah(){
		cek_session_admin();
		if (isset($_POST['submit'])){
	   	$data = array(
				'nama_carrier' => $this->input->post('nama_carrier')
			);

	  	$insert = $this->carrier->save($data);
	  	$this->session->set_flashdata('success',' Tambah Data Carrier');
	  	redirect('carrier');
		}else{
		$data ['title']	= $this->title;
		$this->template->load('template',$this->folder.'/tambah',$data);		
		}
	}

	function getdata()
	{
		cek_session_admin();
		$list = $this->carrier->get_datatables();
		$data = array();
		$no = $_POST['start'];
		
		foreach ($list as $field) {
			
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $field->nama_carrier;
			$row[] = $field->aktif;
			//add html for action
			$row[] = '<a class="btn  btn-xs btn-default" href="'.base_url()."carrier/edit/".md5($field->id_carrier).'" title="Edit" ><i class="fa fa-pencil"></i></a>
				  <a class="btn btn-xs btn-danger" href="javascript:void(0)" title="Hapus" onclick="hapus('."'".$field->id_carrier."'".')"><i class="glyphicon glyphicon-trash"></i> </a>';

			$data[] = $row;
		}

		$output = array(
			"draw" => $_POST['draw'],
			"recordsTotal" => $this->carrier->count_all(),
			"recordsFiltered" => $this->carrier->count_filtered(),
			"data" => $data,
		);
		//output dalam format JSON
		echo json_encode($output);
	}


	public function hapus($id)
	{
		cek_session_admin();
		$this->carrier->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}



}
