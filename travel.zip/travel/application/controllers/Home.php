<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('model_pengaturan','pengaturan');
	}
	function index(){
		cek_session_admin();
		$data['record'] = $this->pengaturan->get_pengaturan()->row_array();
	   	$this->template->load('template','home',$data);
	}


}
