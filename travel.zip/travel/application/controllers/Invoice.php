<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Invoice extends CI_Controller {
	
	var $folder =   "main/invoice";
	var $title  =   "Invoice";

	function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('Model_invoice','invoice');
		$this->load->model('Model_reservasi','reservasi');
		$this->load->model('Model_pengaturan','pengaturan');
		$this->load->library('dompdf_gen');
		$this->load->library('upload');
	}

	function index(){
		cek_session_admin();
		$data ['title']	= $this->title;	   	
		$this->template->load('template',$this->folder.'/invoice',$data);
	}

	function tgl_to_sql($date){
		$exp = explode('-',$date);
		if(count($exp) == 3) {
			$date = $exp[2].'-'.$exp[1].'-'.$exp[0];
		}
		return $date;
	}

	function edit($id = NULL){
		cek_session_admin();
		if (isset($_POST['submit'])){
			$insert = $this->invoice->ubah();
			$this->session->set_flashdata('success',' Edit Invoice');
        	redirect('invoice');

      }else{
      	if ($id == NULL){
      		redirect('invoice');
      	}
      	$data ['title']	= $this->title;
      	$data['reservasi'] = $this->invoice->reservasi_edit();
      	$data ['record']= $this->invoice->get_by_id_md5($id);

      	$this->template->load('template',$this->folder.'/edit',$data);	
      }

    }

    function reservasi($id = NULL){
    	cek_session_admin();
    	if (isset($_POST['submit'])){
    		$data = array(
    			'id_invoice' => $this->input->post('id_invoice'),
    			'id_reservasi' => $this->input->post('id_reservasi'),
    			'jumlah' => $this->input->post('jumlah')
    		);
    		$data_reservasi = array('balance' => $this->input->post('status'),
    			'no_invoice' => $this->input->post('id_invoice'));
    		$insert = $this->invoice->save_reservasi($data);
    		$this->reservasi->update(array('id_reservasi' => $this->input->post('id_reservasi')), $data_reservasi);
    		$this->session->set_flashdata('success',' Menambahkan Reservasi');
    		redirect('invoice/reservasi/'.md5($this->input->post('id_invoice')));
    	}else{
    		if ($id == NULL){
    			redirect('invoice');
    		}
    		$data ['title']	= $this->title;
    		$data['reservasi'] = $this->invoice->reservasi();
    		$data ['record']= $this->invoice->get_by_id_md5($id);

    		$this->template->load('template',$this->folder.'/reservasi',$data);	
    	}

    }

    function cetak($id){

    	$data ['record']= $this->invoice->get_by_id_md5($id);
    	$data ['pengaturan'] = $this->pengaturan->get_pengaturan()->row_array();
    	$dt= $this->invoice->get_by_id_md5($id);
    	$this->load->view('welcome_message', $data);
    	$html = $this->output->get_output();
    	$this->load->library('dompdf_gen');
    	$this->dompdf->load_html($html);
    	$this->dompdf->set_paper('A4', 'portrait');
    	$this->dompdf->render();
    	$this->dompdf->stream("Invoice-".$dt['id_invoice']."-".date('dmY').".pdf", array('Attachment' => 0));
    }

    function tambah(){
    	cek_session_admin();
    	if (isset($_POST['submit'])){
    		$insert = $this->invoice->save();
    		$this->session->set_flashdata('success',' Tambah Invoice');
    		redirect('invoice');

    	}else{
    		$data ['title']	= $this->title;
    		$data['reservasi'] = $this->invoice->reservasi();
    		$data['kodeunik'] = $this->invoice->get_no_invoice();
    		$this->template->load('template',$this->folder.'/tambah',$data);		
    	}
    }

    function getdata()
    {
    	cek_session_admin();
    	$list = $this->invoice->get_datatables();
    	$data = array();
    	$no = $_POST['start'];

    	foreach ($list as $field) {
    		$jumlah = $this->invoice->jumlah_reservasi($field->id_invoice)->row_array();
    		if ($field->status_invoice == 'Credit'){
    			$status = 'Credit';
    		}elseif($field->status_invoice == 'Lunas'){
    			$status = 'Lunas';
    		}elseif($field->status_invoice == 'BRI'){
    			$status = 'BRI';
    		}else{
    			$status ='BNI';
    		}

    		$cek = $this->invoice->cek_data($field->id_invoice);
    		if($cek->num_rows() > 0){
    			$dt = '<a class="btn  btn-xs btn-default" href="'.base_url()."invoice/edit/".md5($field->id_invoice).'" title="Edit" ><i class="fa fa-pencil"></i></a>

    			<a class="btn btn-xs btn-success" target="_blank" href="'.base_url()."invoice/cetak/".md5($field->id_invoice).'"title="Cetak" ><i class="glyphicon glyphicon-print"></i> </a>
    			';
    		}else{
    			$dt = '<a class="btn  btn-xs btn-default" href="'.base_url()."invoice/edit/".md5($field->id_invoice).'" title="Edit" ><i class="fa fa-pencil"></i></a>

    			<a class="btn btn-xs btn-success" target="_blank" href="'.base_url()."invoice/cetak/".md5($field->id_invoice).'"title="Cetak" ><i class="glyphicon glyphicon-print"></i> </a>
    			<a class="btn  btn-xs btn-danger" href="'.base_url()."invoice/hapus/".md5($field->id_invoice).'" title="Hapus" onclick="return confirm(\'Apa anda yakin untuk hapus Data ini?\')" ><i class="fa fa-trash"></i></a>';
    		}

    		$no++;
    		$row = array();
    		$row[] = $no;
    		$row[] = $field->id_invoice;
    		$row[] = $field->passenger;
    		$row[] = DATE('d-m-Y',strtotime($field->tanggal_invoice));
    		$row[] = 'Rp. '.number_format($jumlah['jml'], 0 ,',',',');
    		$row[] = $status;
    		$row[] = '<a class="btn  btn-xs btn-warning" href="'.base_url()."invoice/reservasi/".md5($field->id_invoice).'" title="Data Reservasi" >Data Reservasi</a>';
			//add html for action
    		$row[] = $dt;

    		$data[] = $row;
    	}

    	$output = array(
    		"draw" => $_POST['draw'],
    		"recordsTotal" => $this->invoice->count_all(),
    		"recordsFiltered" => $this->invoice->count_filtered(),
    		"data" => $data,
    	);
		//output dalam format JSON
    	echo json_encode($output);
    }


    public function hapus2($id)
    {
    	cek_session_admin();

    	$this->invoice->delete_by_id($id);
    	echo json_encode(array("status" => TRUE));
    }


    public function hapus($id)
    {
    	cek_session_admin();
    	$this->invoice->hapus_by_id_md5($id);
    	redirect('invoice');
    }

    public function hapus_reservasi($id)
    {
    	cek_session_admin();
    	$data =$this->invoice->get_detail_by_id_md5($id);
    	$data_reservasi = array('balance' => 'Credit', 'no_invoice' => '');
    	$this->reservasi->update(array('id_reservasi' => $data['id_reservasi']), $data_reservasi);
    	$this->invoice->hapus_detail_by_id_md5($id);
    	$this->session->set_flashdata('success',' Menghapus Reservasi');
    	redirect('invoice/reservasi/'.md5($data['id_invoice']));
    }

    public function export(){

    	include APPPATH.'third_party/PHPExcel/PHPExcel.php';
    	$excel = new PHPExcel();

    	$excel->getProperties()->setCreator('Aplikasi Reservasi')
    	->setLastModifiedBy('Aplikasi Reservasi')
    	->setTitle("Data Invoice")
    	->setSubject("Invoice")
    	->setDescription("Laporan Data Invoice")
    	->setKeywords("Data Invoice");


    	$style_col = array(
    		'font' => array('bold' => true), 
    		'alignment' => array(
    			'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, 
    			'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER 
    		),
    		'borders' => array(
    			'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),
    			'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  
    			'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), 
    			'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN)
    		)
    	);


    	$style_row = array(
    		'alignment' => array(
    			'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER 
    		),
    		'borders' => array(
    			'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), 
    			'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  
    			'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),
    			'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) 
    		)
    	);

    	$excel->setActiveSheetIndex(0)->setCellValue('A1', "DATA INVOICE");
    	$excel->getActiveSheet()->mergeCells('A1:L1'); 
    	$excel->getActiveSheet()->getStyle('A1')->getFont()->setBold(TRUE); 
    	$excel->getActiveSheet()->getStyle('A1')->getFont()->setSize(15); 
    	$excel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);


    	$excel->setActiveSheetIndex(0)->setCellValue('A3', "NO"); 
    	$excel->setActiveSheetIndex(0)->setCellValue('B3', "ID INVOICE"); 
    	$excel->setActiveSheetIndex(0)->setCellValue('C3', "ID RESERVASI"); 
    	$excel->setActiveSheetIndex(0)->setCellValue('D3', "PESENGGER NAME"); 
    	$excel->setActiveSheetIndex(0)->setCellValue('E3', "TANGGAL"); 
    	$excel->setActiveSheetIndex(0)->setCellValue('F3', "JATUH TEMPO");
    	$excel->setActiveSheetIndex(0)->setCellValue('G3', "JUMLAH"); 
    	$excel->setActiveSheetIndex(0)->setCellValue('H3', "STATUS"); 

    	$excel->getActiveSheet()->getStyle('A3')->applyFromArray($style_col);
    	$excel->getActiveSheet()->getStyle('B3')->applyFromArray($style_col);
    	$excel->getActiveSheet()->getStyle('C3')->applyFromArray($style_col);
    	$excel->getActiveSheet()->getStyle('D3')->applyFromArray($style_col);
    	$excel->getActiveSheet()->getStyle('E3')->applyFromArray($style_col);
    	$excel->getActiveSheet()->getStyle('F3')->applyFromArray($style_col);
    	$excel->getActiveSheet()->getStyle('G3')->applyFromArray($style_col);
    	$excel->getActiveSheet()->getStyle('H3')->applyFromArray($style_col);


    	$invoice = $this->invoice->view();

    	$no = 1; 
    	$numrow = 4; 
    	foreach($invoice as $data){ 
    		$jumlah = $this->invoice->jumlah_reservasi($data->id_invoice)->row_array();


    		$tampil_id = '';
    		$detail_reservasi= $this->invoice->detail_reservasi($data->id_invoice);
    		foreach ($detail_reservasi->result_array() as $key) {
    			$tampil_id .= $key['id_reservasi'].', ';
    		}

    		if ($data->status_invoice == 'Credit'){
    			$status = 'Credit';
    		}elseif($data->status_invoice == 'Lunas'){
    			$status = 'Lunas';
    		}elseif($data->status_invoice == 'BRI'){
    			$status = 'BRI';
    		}else{
    			$status ='BNI';
    		}

    		$excel->setActiveSheetIndex(0)->setCellValue('A'.$numrow, $no);
    		$excel->setActiveSheetIndex(0)->setCellValue('B'.$numrow, $data->id_invoice);
    		$excel->setActiveSheetIndex(0)->setCellValue('C'.$numrow, $tampil_id );
    		$excel->setActiveSheetIndex(0)->setCellValue('D'.$numrow, $data->passenger);
    		$excel->setActiveSheetIndex(0)->setCellValue('E'.$numrow, DATE('d-m-Y',strtotime($data->tanggal_invoice)));

    		$excel->setActiveSheetIndex(0)->setCellValue('F'.$numrow, DATE('d-m-Y',strtotime($data->tanggal_tempo)));
    		$excel->setActiveSheetIndex(0)->setCellValue('G'.$numrow, 'Rp. '.number_format($jumlah['jml'], 0 ,',',','));
    		$excel->setActiveSheetIndex(0)->setCellValue('H'.$numrow, $status);


    		$excel->getActiveSheet()->getStyle('A'.$numrow)->applyFromArray($style_row);
    		$excel->getActiveSheet()->getStyle('B'.$numrow)->applyFromArray($style_row);
    		$excel->getActiveSheet()->getStyle('C'.$numrow)->applyFromArray($style_row);
    		$excel->getActiveSheet()->getStyle('D'.$numrow)->applyFromArray($style_row);
    		$excel->getActiveSheet()->getStyle('E'.$numrow)->applyFromArray($style_row);
    		$excel->getActiveSheet()->getStyle('F'.$numrow)->applyFromArray($style_row);
    		$excel->getActiveSheet()->getStyle('G'.$numrow)->applyFromArray($style_row);
    		$excel->getActiveSheet()->getStyle('H'.$numrow)->applyFromArray($style_row);

    		$no++; 
    		$numrow++; 
    	}


    	$excel->getActiveSheet()->getColumnDimension('A')->setWidth(5); 
    	$excel->getActiveSheet()->getColumnDimension('B')->setWidth(15); 
    	$excel->getActiveSheet()->getColumnDimension('C')->setWidth(25); 
    	$excel->getActiveSheet()->getColumnDimension('D')->setWidth(20); 
    	$excel->getActiveSheet()->getColumnDimension('E')->setWidth(30); 
    	$excel->getActiveSheet()->getColumnDimension('F')->setWidth(30); 
    	$excel->getActiveSheet()->getColumnDimension('G')->setWidth(30); 
    	$excel->getActiveSheet()->getColumnDimension('H')->setWidth(30); 



    	$excel->getActiveSheet()->getDefaultRowDimension()->setRowHeight(-1);

    	$excel->getActiveSheet()->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);


    	$excel->getActiveSheet(0)->setTitle("Laporan Data Invoice");
    	$excel->setActiveSheetIndex(0);


    	header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    	header('Content-Disposition: attachment; filename="Data_Invoice_'.DATE('d-m-Y').'.xlsx"'); 
    	header('Cache-Control: max-age=0');

    	$write = PHPExcel_IOFactory::createWriter($excel, 'Excel2007');
    	$write->save('php://output');
    }

  }
