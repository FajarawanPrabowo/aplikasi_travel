<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Laba_rugi extends CI_Controller {
	
	var $folder =   "main/laba_rugi";
    var $title  =   "Laporan Laba Rugi";

	function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('Model_pengeluaran','laba_rugi');
		$this->load->model('Model_pengaturan','pengaturan');
	}

	function index(){
		cek_session_admin();
	   	$data ['title']	= $this->title;	   	
		$this->template->load('template',$this->folder.'/laba_rugi',$data);
	}

	function tgl_to_sql($date){
	$exp = explode('-',$date);
		if(count($exp) == 3) {
			$date = $exp[2].'-'.$exp[1].'-'.$exp[0];
		}
		return $date;
	}


	public function get_data(){
        cek_session_admin();
        $tgl_awal     = $this->tgl_to_sql($_GET['tgl_awal']);
        $tgl_akhir     = $this->tgl_to_sql($_GET['tgl_akhir']);
        $penjualan = $this->laba_rugi->penjualan($tgl_awal,$tgl_akhir);
        $pengeluaran = $this->laba_rugi->pengeluaran($tgl_awal,$tgl_akhir);
    	 echo "<a  href='".base_url()."laba_rugi/cetak_print?tgl_awal=".$_GET['tgl_awal']."&tgl_akhir=".$_GET['tgl_akhir']."' class=\"btn btn-warning btn-sm\" target=\"_blank\" >Cetak</a>";

        echo "<br><br>Tanggal : ".$_GET['tgl_awal']." s.d ".$_GET['tgl_akhir']."<br><br> ";
        
        echo "<table class=\"table  table-bordered\" cellspacing=\"0\" width=\"100%\" border=\"0\"  >
                    <thead>
                        <tr style=\"background: linear-gradient(to right, rgb(0, 166, 90),rgba(255, 255, 255, 0.8));color: #fff;\" >
                            <th colspan='2' >Pendapatan Dari Penjualan</th>
                        </tr>
                    </thead>
                    <tbody>";
                    $profit = 0;
                    $total = 0;
                    $total_profit = 0;
                    foreach ($penjualan->result_array() as $row){
                    $profit =	$row['sale'];
                    $total_profit += $profit;
                    $sale =	$row['sale'];
                    $total += $row['sale'];
                    echo "<tr>
                    	<td>$row[produk]</td>
                    	<td width='200' > Rp. ".number_format($sale, 0 ,'.','.')."</td>
                    <tr>
                    
                    ";
                }
                    
                    echo "<tr>
                    	<th style=\"text-align:right;\" >Total</th>
                    	<th width='200'>Rp. ".number_format($total, 0 ,'.','.')."</th>
                    <tr>
                    <tr >
                    	<th style=\"text-align:right;\">Profit</th>
                    	<th style=\"background: #0f6b41;color: #fff;\">Rp. ".number_format($total_profit, 0 ,'.','.')."</th>
                    <tr>
                    </tbody>
                </table>
            </div>

        ";
        echo "<table class=\"table  table-bordered\" cellspacing=\"0\" width=\"100%\" border=\"0\"  >
                    <thead>
                        <tr style=\"background:linear-gradient(to right, rgb(210, 24, 11),rgba(255, 255, 255, 0.8));color: #fff;\" >
                            <th colspan='2' >Biaya Operasional</th>
                        </tr>
                    </thead>
                    <tbody>";

                    $total_pengeluaran = 0;
                    foreach ($pengeluaran->result_array() as $row){
                    $pendapatan =	$row['total'];
                    $total_pengeluaran += $row['total'];
                    echo "<tr>
                    	<td>$row[kategori]</td>
                    	<td width='200' > Rp. ".number_format($pendapatan, 0 ,'.','.')."</td>
                    <tr>
                    
                    ";
                }
                    echo "<tr>
                    	<th style=\"text-align:right;\">Total</th>
                    	<th width='200'>Rp. ".number_format($total_pengeluaran, 0 ,'.','.')."</th>
                    <tr>
                    </tbody>
                </table>
            </div>

        ";

        echo "<table class=\"table  table-bordered\" cellspacing=\"0\" width=\"100%\" border=\"0\"  >
                    <thead>
                        <tr style='background:#ededed;' >
                            <th style=\"text-align:right;\" >Pendapatan Bersih</th>
                            <th width=\"200\">Rp. ".number_format($total_profit-$total_pengeluaran, 0 ,'.','.')."</th>
                        </tr>
                    </thead>
                   
                </table>
            </div>

        ";


    	
     }


	function edit($id = NULL){
		cek_session_admin();
		if (isset($_POST['submit'])){
		$data = array(
				'tanggal_pengeluaran' => $this->tgl_to_sql($this->input->post('tanggal')),
				'id_kategori' => $this->input->post('id_kategori'),
				'penerima' => $this->input->post('penerima'),
				'total' => $this->input->post('total'),
				'deskripsi' => $this->input->post('deskripsi')
			);


	  	$this->pengeluaran->update(array('id_pengeluaran' => $this->input->post('id_pengeluaran')), $data);
	  	$this->session->set_flashdata('success',' Edit Laporan Pengeluaran');
	  	redirect('pengeluaran');
		}else{
		if ($id == NULL){
			redirect('pengeluaran');
		}
		$data ['title']	= $this->title;
		$data['kategori'] = $this->pengeluaran->kategori();
		$data ['record']= $this->pengeluaran->get_by_id_md5($id);
		$this->template->load('template',$this->folder.'/edit',$data);	
		}
		
	}


	function detail($id){
		if ($id == NULL){
			redirect('reservasi');
		}
		$data ['title']	= $this->title;
		$data ['record']= $this->reservasi->get_by_id_md5($id);
		$this->template->load('template',$this->folder.'/detail',$data);	
	}

	

	function tambah(){
		cek_session_admin();
		if (isset($_POST['submit'])){
	   	$data = array(
				'tanggal_pengeluaran' => $this->tgl_to_sql($this->input->post('tanggal')),
				'id_kategori' => $this->input->post('id_kategori'),
				'penerima' => $this->input->post('penerima'),
				'total' => $this->input->post('total'),
				'deskripsi' => $this->input->post('deskripsi')
			);

	  	$insert = $this->pengeluaran->save($data);
	  	$this->session->set_flashdata('success',' Tambah Data Pengeluaran');
	  	redirect('pengeluaran');
		}else{
		$data ['title']	= $this->title;
		$data['kategori'] = $this->pengeluaran->kategori();
		$this->template->load('template',$this->folder.'/tambah',$data);		
		}
	}

	function getdata()
	{
		cek_session_admin();
		$list = $this->pengeluaran->get_datatables();
		$data = array();
		$no = $_POST['start'];
		
		foreach ($list as $field) {
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = DATE('d-m-Y',strtotime($field->tanggal_pengeluaran));
			$row[] = $field->kategori;
			$row[] = $field->deskripsi;
			$row[] = $field->penerima;
			$row[] = "Rp. ".number_format($field->total, 0 ,'.','.');
			//add html for action
			$row[] = '<a class="btn  btn-xs btn-default" href="'.base_url()."pengeluaran/edit/".md5($field->id_pengeluaran).'" title="Edit" ><i class="fa fa-pencil"></i></a>
				  <a class="btn btn-xs btn-danger" href="javascript:void(0)" title="Hapus" onclick="hapus('."'".$field->id_pengeluaran."'".')"><i class="glyphicon glyphicon-trash"></i> </a>';

			$data[] = $row;
		}

		$output = array(
			"draw" => $_POST['draw'],
			"recordsTotal" => $this->pengeluaran->count_all(),
			"recordsFiltered" => $this->pengeluaran->count_filtered(),
			"data" => $data,
		);
		//output dalam format JSON
		echo json_encode($output);
	}


	

	public function cetak_print(){
        cek_session_admin();
        $data['record'] = $this->pengaturan->get_pengaturan()->row_array();
        $tgl_awal     = $this->tgl_to_sql($_GET['tgl_awal']);
        $tgl_akhir     = $this->tgl_to_sql($_GET['tgl_akhir']);
        $data['penjualan'] = $this->laba_rugi->penjualan($tgl_awal,$tgl_akhir);
        $data['pengeluaran'] = $this->laba_rugi->pengeluaran($tgl_awal,$tgl_akhir);
        $this->load->view('print',$data);
    }



}
