<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	function __construct(){
		parent::__construct();	
		$this->load->library('session');
		$this->load->model('model_login','login');
 
	}

	function index(){
		if ($this->session->status != ''){
			redirect('home');
		}else{
			$this->load->view('login');
		}
	}

	function submit(){
		$username	= $this->input->post('a');
		$password	= md5($this->input->post('b'));

		$cek_admin = $this->login->cek_admin($username,$password);
		if($cek_admin->num_rows() > 0){
			$row = $cek_admin->row_array();
		    $total = $cek_admin->num_rows();
 			if ($total > 0){
			$data_session = array(
				'status' => 'login',
				'nama_lengkap' => $row['nama_lengkap'],
				'id' => $row['id_user'],
				'level'	=> $row['level'],
				);
 
				$this->session->set_userdata($data_session);
				redirect('home');

			}else{
				
				$this->session->set_flashdata('salah',TRUE);
				redirect('login');
				
			}
 
		}else{
			
				$this->session->set_flashdata('salah',TRUE);
					redirect('login');
		}
	}


	

}
