<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Omset extends CI_Controller {
	
	var $folder =   "main/omset";
    var $title  =   "Laporan Omset";

	function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('Model_invoice','invoice');
		$this->load->model('Model_reservasi','reservasi');
		$this->load->model('Model_pengaturan','pengaturan');
		$this->load->library('dompdf_gen');
	}

	function index(){
		cek_session_admin();
	   	$data ['title']	= $this->title;	   	
		$this->template->load('template',$this->folder.'/omset',$data);
	}

	function tgl_to_sql($date){
    $exp = explode('-',$date);
        if(count($exp) == 3) {
            $date = $exp[2].'-'.$exp[1].'-'.$exp[0];
        }
        return $date;
    }

    function cetak(){
        $tgl_awal     = $this->tgl_to_sql($_GET['tgl_awal']);
        $tgl_akhir     = $this->tgl_to_sql($_GET['tgl_akhir']);
        $status    =   $_GET['status'];
        if ($status == '') {
            $data['omset'] = $this->invoice->omset_no_status($tgl_awal,$tgl_akhir);
        }else{
            $data['omset'] = $this->invoice->omset_status($tgl_awal,$tgl_akhir,$status);
        }
        $data ['pengaturan'] = $this->pengaturan->get_pengaturan()->row_array();
        $this->load->view('omset',$data);
        $html = $this->output->get_output();
        $this->load->library('dompdf_gen');
        $this->dompdf->load_html($html);
        $this->dompdf->set_paper('A4', 'portrait');
        $this->dompdf->render();
        $this->dompdf->stream("Laporan_Omset-".date('dmY').".pdf", array('Attachment' => 0));
    }

	 public function get(){
        cek_session_admin();
        $tgl_awal     = $this->tgl_to_sql($_GET['tgl_awal']);
        $tgl_akhir     = $this->tgl_to_sql($_GET['tgl_akhir']);
        $status    =   $_GET['status'];
        if ($status == '') {
            $db_omset = $this->invoice->omset_no_status($tgl_awal,$tgl_akhir);
        }else{
            $db_omset = $this->invoice->omset_status($tgl_awal,$tgl_akhir,$status);
        }
        
        

        echo "
             <div class=\"row\">
             
            </div>
            <div class=\"box-body\">

              <table class=\"table table-striped table-bordered\" cellspacing=\"0\" width=\"100%\" border='1'  >
                    <thead>
                        <tr>
                            <th width=\"5\">No</th>
                            <th>ID Invoice</th>
                            <th>Passenger Name</th>
                            <th>Tanggal</th>
                            <th>Status</th>
                            <th>Jumlah</th>
                            
                        </tr>
                    </thead>
                    <tbody>";
                  	 if ($db_omset->num_rows() > 0){
                  	$no = 1;
                    $jumlah = 0;
                    foreach ($db_omset->result_array() as $row){
                    $jml = $this->invoice->jumlah_reservasi($row['id_invoice'])->row_array();
                    	echo "<tr>
                    			<td>$no</td>
                    			<td>$row[id_invoice]</td>
                                <td>$row[passenger]</td>
                    			<td>".DATE('d-m-Y',strtotime($row['tanggal_invoice']))."</td>
                    			
                                <td> $row[status_invoice]</td>
                    			<td>Rp. ".number_format($jml['jml'], 0 ,',',','). "</td>
                    			
                    		  </tr>
                    			";
                    $no++;            
                    $jumlah = $jumlah + $jml['jml'];
                    }
                    echo "<tr>
                          <th colspan=\"5\" class=\"text-right\">Jumlah Keseluruhan</th>
                          <th>Rp. ".number_format($jumlah, 0 ,',',','). "</th>
                        </tr>
                    ";  
                    }else{
                        echo "<tr>
                          <td colspan=\"6\" class=\"text-center\">Data Tidak ditemukan.</td>
                        </tr>
                    ";  
                    }

                    echo "</tbody>
                </table>
            </div>

        ";

     }

}
