<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pencarian extends CI_Controller {
	
	var $folder =   "main/pencarian";
    var $title  =   "Pencarian";

	function __construct(){
		parent::__construct();
		$this->load->helper('url');
        $this->load->model('Model_pencarian','pencarian');
		$this->load->model('Model_reservasi','reservasi');
		$this->load->model('Model_pengaturan','pengaturan');
		$this->load->library('dompdf_gen');
	}

	function index(){
		cek_session_admin();
	   	$data ['title']	= $this->title;	 
        $data['rute'] = $this->reservasi->rute();  	
		$this->template->load('template',$this->folder.'/pencarian',$data);
	}

	function tgl_to_sql($date){
    $exp = explode('-',$date);
        if(count($exp) == 3) {
            $date = $exp[2].'-'.$exp[1].'-'.$exp[0];
        }
        return $date;
    }

  

	 public function get(){
        cek_session_admin();
        $dept     = $_GET['dept'];
        $dest     = $_GET['dest'];
        $date     = $this->tgl_to_sql($_GET['date']);
        $db_cari = $this->pencarian->pencarian($dept,$dest,$date);
       
        

        echo "
             <div class=\"row\">
             
            </div>
            <div class=\"box-body\">

              <table class=\"table table-striped table-bordered\" cellspacing=\"0\" width=\"100%\" border='1'  >
                    <thead>
                        <tr>
                            <th width=\"5\">No</th>
                            <th>ID Reservasi</th>
                            <th>Tanggal</th>
                            <th>Pelanggan</th>
                            <th>Date</th>
                            <th>Tujuan</th>
                            <th>Kendaraan</th>
                            <!--<th>Date Limit</th>
                            <th>Time Limit</th>
                            <th>PNR</th>-->
                            <th>Balance</th>
                            <th>Status</th>
                            
                        </tr>
                    </thead>
                    <tbody>";
                  	 if ($db_cari->num_rows() > 0){
                  	$no = 1;
                    $jumlah = 0;
                    foreach ($db_cari->result_array() as $row){
                    if ($row['balance'] == 'Credit'){
                            $balance = 'Credit';
                        }elseif($row['balance'] == 'Lunas'){
                            $balance = 'Lunas';
                        }elseif($row['balance'] == 'BRI'){
                            $balance = 'BRI';
                        }else{
                            $balance ='BNI';
                        }
                        $dept = $this->db->query("SELECT * FROM sn_rute WHERE id_rute='".$row['dest']."'");
                        $dept_tampil = $dept->row_array();
                    	echo "<tr>
                    			<td>$no</td>
                    			<td>$row[id_reservasi]</td>
                                <td>".DATE('d-m-Y',strtotime($row['tanggal']))."</td>
                    			<td>$row[passenger_name]</td>
                                <td>".DATE('d-m-Y',strtotime($row['date']))."</td>
                                <td>".$dept_tampil['nama_rute']."</td>
                                <td>$row[nama_carrier]</td>
                                <!--<td>".DATE('d-m-Y',strtotime($row['date_limit']))."</td>
                                <td>".DATE('H:i',strtotime($row['time_limit']))."</td>
                                <td>$row[pnr]</td>-->
                                <td>$balance</td>
                    			<td>$row[status]</td>
                    			
                    		  </tr>
                    			";
                    $no++;            
                  
                    }
                   
                    }else{
                        echo "<tr>
                          <td colspan=\"12\" class=\"text-center\">Data Tidak ditemukan.</td>
                        </tr>
                    ";  
                    }

                    echo "</tbody>
                </table>
            </div>

        ";

     }

}
