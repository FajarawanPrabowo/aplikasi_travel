<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Pengaturan extends CI_Controller {
	var $folder =   "main/pengaturan";
    var $title  =   "Pengaturan";
	public function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('model_pengaturan','pengaturan');
		$this->load->library('upload');
	}



	function index(){
        cek_session_admin();
        cek_session_user();
        if (isset($_POST['submit'])){
        	$this->pengaturan->pengaturan();
        	$this->session->set_flashdata('success',' Edit Pengaturan');
			redirect('pengaturan');
        }else{
        $data ['title']	= $this->title;
        $data['record'] = $this->pengaturan->get_pengaturan()->row_array();	   	
		$this->template->load('template',$this->folder.'/pengaturan',$data);
		}
	}

}