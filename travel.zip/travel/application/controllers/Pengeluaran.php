<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pengeluaran extends CI_Controller {
	
	var $folder =   "main/pengeluaran";
    var $title  =   "Laporan Pengeluaran";

	function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('Model_pengeluaran','pengeluaran');
	}

	function index(){
		cek_session_admin();
	   	$data ['title']	= $this->title;	   	
		$this->template->load('template',$this->folder.'/pengeluaran',$data);
	}

	function tgl_to_sql($date){
	$exp = explode('-',$date);
		if(count($exp) == 3) {
			$date = $exp[2].'-'.$exp[1].'-'.$exp[0];
		}
		return $date;
	}

	function edit($id = NULL){
		cek_session_admin();
		if (isset($_POST['submit'])){
		$data = array(
				'tanggal_pengeluaran' => $this->tgl_to_sql($this->input->post('tanggal')),
				'id_kategori' => $this->input->post('id_kategori'),
				'penerima' => $this->input->post('penerima'),
				'total' => $this->input->post('total'),
				'deskripsi' => $this->input->post('deskripsi')
			);


	  	$this->pengeluaran->update(array('id_pengeluaran' => $this->input->post('id_pengeluaran')), $data);
	  	$this->session->set_flashdata('success',' Edit Laporan Pengeluaran');
	  	redirect('pengeluaran');
		}else{
		if ($id == NULL){
			redirect('pengeluaran');
		}
		$data ['title']	= $this->title;
		$data['kategori'] = $this->pengeluaran->kategori();
		$data ['record']= $this->pengeluaran->get_by_id_md5($id);
		$this->template->load('template',$this->folder.'/edit',$data);	
		}
		
	}


	function detail($id){
		if ($id == NULL){
			redirect('reservasi');
		}
		$data ['title']	= $this->title;
		$data ['record']= $this->reservasi->get_by_id_md5($id);
		$this->template->load('template',$this->folder.'/detail',$data);	
	}

	

	function tambah(){
		cek_session_admin();
		if (isset($_POST['submit'])){
	   	$data = array(
				'tanggal_pengeluaran' => $this->tgl_to_sql($this->input->post('tanggal')),
				'id_kategori' => $this->input->post('id_kategori'),
				'penerima' => $this->input->post('penerima'),
				'total' => $this->input->post('total'),
				'deskripsi' => $this->input->post('deskripsi')
			);

	  	$insert = $this->pengeluaran->save($data);
	  	$this->session->set_flashdata('success',' Tambah Data Pengeluaran');
	  	redirect('pengeluaran');
		}else{
		$data ['title']	= $this->title;
		$data['kategori'] = $this->pengeluaran->kategori();
		$this->template->load('template',$this->folder.'/tambah',$data);		
		}
	}

	function getdata()
	{
		cek_session_admin();
		$list = $this->pengeluaran->get_datatables();
		$data = array();
		$no = $_POST['start'];
		
		foreach ($list as $field) {
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = DATE('d-m-Y',strtotime($field->tanggal_pengeluaran));
			$row[] = $field->kategori;
			$row[] = $field->deskripsi;
			$row[] = $field->penerima;
			$row[] = "Rp. ".number_format($field->total, 0 ,'.','.');
			//add html for action
			$row[] = '<a class="btn  btn-xs btn-default" href="'.base_url()."pengeluaran/edit/".md5($field->id_pengeluaran).'" title="Edit" ><i class="fa fa-pencil"></i></a>
				  <a class="btn btn-xs btn-danger" href="javascript:void(0)" title="Hapus" onclick="hapus('."'".$field->id_pengeluaran."'".')"><i class="glyphicon glyphicon-trash"></i> </a>';

			$data[] = $row;
		}

		$output = array(
			"draw" => $_POST['draw'],
			"recordsTotal" => $this->pengeluaran->count_all(),
			"recordsFiltered" => $this->pengeluaran->count_filtered(),
			"data" => $data,
		);
		//output dalam format JSON
		echo json_encode($output);
	}


	public function hapus($id)
	{
		cek_session_admin();
		$this->pengeluaran->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}



}
