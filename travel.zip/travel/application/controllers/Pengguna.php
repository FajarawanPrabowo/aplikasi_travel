<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pengguna extends CI_Controller {
	
	var $folder =   "main/pengguna";
    var $title  =   "Pengguna";

	function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('Model_pengguna','pengguna');
		$this->load->model('Model_reservasi','reservasi');
		$this->load->library('dompdf_gen');
	}

	function index(){
		cek_session_admin();
		cek_session_user();
	   	$data ['title']	= $this->title;	   	
		$this->template->load('template',$this->folder.'/pengguna',$data);
	}

	function tgl_to_sql($date){
	$exp = explode('-',$date);
		if(count($exp) == 3) {
			$date = $exp[2].'-'.$exp[1].'-'.$exp[0];
		}
		return $date;
	}

	function edit($id = NULL){
		cek_session_admin();
		cek_session_user();
		if (isset($_POST['submit'])){
		if ($this->input->post('password') == ''){
		$data = array(
				'username' => $this->input->post('username'),
				'nama_lengkap' => $this->input->post('nama_lengkap'),
				'level' => $this->input->post('level'));
		}else{
		$data = array(
				'username' => $this->input->post('username'),
				'password' => md5($this->input->post('password')),
				'nama_lengkap' => $this->input->post('nama_lengkap'),
				'level' => $this->input->post('level'));	
		}
		
	  	$this->pengguna->update(array('id_user' => $this->input->post('id')), $data);
	  	$this->session->set_flashdata('success',' Edit Pengguna');
	  	redirect('pengguna');
		}else{
		if ($id == NULL){
			redirect('pengguna');
		}
		$data ['title']	= $this->title;
		$data ['record']= $this->pengguna->get_by_id_md5($id);
		$this->template->load('template',$this->folder.'/edit',$data);	
		}
		
	}

	function tambah(){
		cek_session_admin();
		cek_session_user();
		if (isset($_POST['submit'])){
	   	$data = array(
				'username' => $this->input->post('username'),
				'password' => md5($this->input->post('password')),
				'nama_lengkap' => $this->input->post('nama_lengkap'),
				'level' => $this->input->post('level'));
	   	$insert = $this->pengguna->save($data);
	  	$this->session->set_flashdata('success',' Tambah Pengguna');
	  	redirect('pengguna');
		}else{
		$data ['title']	= $this->title;
		$this->template->load('template',$this->folder.'/tambah',$data);		
		}
	}

	function getdata()
	{
		cek_session_admin();
		cek_session_user();
		$list = $this->pengguna->get_datatables();
		$data = array();
		$no = $_POST['start'];
		
		foreach ($list as $field) {
		
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $field->username;
			$row[] = $field->nama_lengkap;
			$row[] = $field->level;
			$row[] = '<a class="btn  btn-xs btn-success" href="'.base_url()."pengguna/edit/".md5($field->id_user).'" title="Edit" ><i class="fa fa-pencil"></i></a>
				 ';

			$data[] = $row;
		}

		$output = array(
			"draw" => $_POST['draw'],
			"recordsTotal" => $this->pengguna->count_all(),
			"recordsFiltered" => $this->pengguna->count_filtered(),
			"data" => $data,
		);
		//output dalam format JSON
		echo json_encode($output);
	}


	public function hapus($id)
	{
		cek_session_admin();
		cek_session_user();
		$this->invoice->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}



}
