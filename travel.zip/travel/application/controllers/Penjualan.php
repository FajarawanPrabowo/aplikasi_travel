<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Penjualan extends CI_Controller {
	
	var $folder =   "main/penjualan";
    var $title  =   "Laporan Penjualan";

	function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('Model_penjualan','penjualan');
	}

	function index(){
		cek_session_admin();
	   	$data ['title']	= $this->title;	   	
		$this->template->load('template',$this->folder.'/penjualan',$data);
	}

	function tgl_to_sql($date){
	$exp = explode('-',$date);
		if(count($exp) == 3) {
			$date = $exp[2].'-'.$exp[1].'-'.$exp[0];
		}
		return $date;
	}

	function edit($id = NULL){
		cek_session_admin();
		if (isset($_POST['submit'])){
		$data = array(
				'tanggal_penjualan' => $this->tgl_to_sql($this->input->post('tanggal')),
				'id_produk' => $this->input->post('id_produk'),
				'id_reservasi' => $this->input->post('id_reservasi'),
				'deskripsi' => $this->input->post('deskripsi')
			);

	  	$this->penjualan->update(array('id_penjualan' => $this->input->post('id_penjualan')), $data);
	  	$this->session->set_flashdata('success',' Edit Data Kategori');
	  	redirect('penjualan');
		}else{
		if ($id == NULL){
			redirect('penjualan');
		}
		$data ['title']	= $this->title;
		$data['produk'] = $this->penjualan->produk();
		$data['reservasi'] = $this->penjualan->reservasi_edit();
		$data ['record']= $this->penjualan->get_by_id_md5($id);
		$this->template->load('template',$this->folder.'/edit',$data);	
		}
		
	}


	function detail($id){
		if ($id == NULL){
			redirect('reservasi');
		}
		$data ['title']	= $this->title;
		$data ['record']= $this->reservasi->get_by_id_md5($id);
		$this->template->load('template',$this->folder.'/detail',$data);	
	}

	

	function tambah(){
		cek_session_admin();
		if (isset($_POST['submit'])){
	   	$data = array(
				'tanggal_penjualan' => $this->tgl_to_sql($this->input->post('tanggal')),
				'id_produk' => $this->input->post('id_produk'),
				'id_reservasi' => $this->input->post('id_reservasi'),
				'deskripsi' => $this->input->post('deskripsi')
			);

	  	$insert = $this->penjualan->save($data);
	  	$this->session->set_flashdata('success',' Tambah Data Penjualan');
	  	redirect('penjualan');
		}else{
		$data ['title']	= $this->title;
		$data['produk'] = $this->penjualan->produk();
		$data['reservasi'] = $this->penjualan->reservasi();
		$this->template->load('template',$this->folder.'/tambah',$data);		
		}
	}

	function getdata()
	{
		cek_session_admin();
		$list = $this->penjualan->get_datatables();
		$data = array();
		$no = $_POST['start'];
		
		foreach ($list as $field) {
			$profit = $field->sale - $field->nta;
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = DATE('d-m-Y',strtotime($field->tanggal_penjualan));
			$row[] = $field->produk;
			$row[] = $field->no_invoice;
			$row[] = $field->deskripsi;
			$row[] = "Rp. ".number_format($profit, 0 ,'.','.');
			//add html for action
			$row[] = '<a class="btn  btn-xs btn-default" href="'.base_url()."penjualan/edit/".md5($field->id_penjualan).'" title="Edit" ><i class="fa fa-pencil"></i></a>
				  <a class="btn btn-xs btn-danger" href="javascript:void(0)" title="Hapus" onclick="hapus('."'".$field->id_penjualan."'".')"><i class="glyphicon glyphicon-trash"></i> </a>';

			$data[] = $row;
		}

		$output = array(
			"draw" => $_POST['draw'],
			"recordsTotal" => $this->penjualan->count_all(),
			"recordsFiltered" => $this->penjualan->count_filtered(),
			"data" => $data,
		);
		//output dalam format JSON
		echo json_encode($output);
	}


	public function hapus($id)
	{
		cek_session_admin();
		$this->penjualan->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}



}
