<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Produk extends CI_Controller {
	
	var $folder =   "main/produk";
    var $title  =   "Data Produk";

	function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('Model_produk','produk');
	}

	function index(){
		cek_session_admin();
	   	$data ['title']	= $this->title;	   	
		$this->template->load('template',$this->folder.'/produk',$data);
	}

	function tgl_to_sql($date){
	$exp = explode('-',$date);
		if(count($exp) == 3) {
			$date = $exp[2].'-'.$exp[1].'-'.$exp[0];
		}
		return $date;
	}

	function edit($id = NULL){
		cek_session_admin();
		if (isset($_POST['submit'])){
		$data = array(
				'produk' => $this->input->post('produk'),
				'aktif' => $this->input->post('aktif'),
			);

	  	$this->produk->update(array('id_produk' => $this->input->post('id_produk')), $data);
	  	$this->session->set_flashdata('success',' Edit Data Produk');
	  	redirect('produk');
		}else{
		if ($id == NULL){
			redirect('produk');
		}
		$data ['title']	= $this->title;
		$data ['record']= $this->produk->get_by_id_md5($id);
		$this->template->load('template',$this->folder.'/edit',$data);	
		}
		
	}


	function detail($id){
		if ($id == NULL){
			redirect('reservasi');
		}
		$data ['title']	= $this->title;
		$data ['record']= $this->reservasi->get_by_id_md5($id);
		$this->template->load('template',$this->folder.'/detail',$data);	
	}

	

	function tambah(){
		cek_session_admin();
		if (isset($_POST['submit'])){
	   	$data = array(
				'produk' => $this->input->post('produk')
			);

	  	$insert = $this->produk->save($data);
	  	$this->session->set_flashdata('success',' Tambah Data Produk');
	  	redirect('produk');
		}else{
		$data ['title']	= $this->title;
		$this->template->load('template',$this->folder.'/tambah',$data);		
		}
	}

	function getdata()
	{
		cek_session_admin();
		$list = $this->produk->get_datatables();
		$data = array();
		$no = $_POST['start'];
		
		foreach ($list as $field) {
			
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $field->produk;
			$row[] = $field->aktif;
			//add html for action
			$row[] = '<a class="btn  btn-xs btn-default" href="'.base_url()."produk/edit/".md5($field->id_produk).'" title="Edit" ><i class="fa fa-pencil"></i></a>
				  <a class="btn btn-xs btn-danger" href="javascript:void(0)" title="Hapus" onclick="hapus('."'".$field->id_produk."'".')"><i class="glyphicon glyphicon-trash"></i> </a>';

			$data[] = $row;
		}

		$output = array(
			"draw" => $_POST['draw'],
			"recordsTotal" => $this->produk->count_all(),
			"recordsFiltered" => $this->produk->count_filtered(),
			"data" => $data,
		);
		//output dalam format JSON
		echo json_encode($output);
	}


	public function hapus($id)
	{
		cek_session_admin();
		$this->produk->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}



}
