<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Reservasi extends CI_Controller {
	
	var $folder =   "main/reservasi";
    var $title  =   "Data Reservasi";

	function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('Model_reservasi','reservasi');
		$this->load->library('upload');
	}

	

	function index(){
		cek_session_admin();
		
	   	$data ['title']	= $this->title;	   	
		$this->template->load('template',$this->folder.'/reservasi',$data);
	}

	function tgl_to_sql($date){
	$exp = explode('-',$date);
		if(count($exp) == 3) {
			$date = $exp[2].'-'.$exp[1].'-'.$exp[0];
		}
		return $date;
	}

	function edit($id = NULL){
		cek_session_admin();
		if (isset($_POST['submit'])){
	
        	$data = array(
				'id_reservasi' => $this->input->post('id_reservasi'),
				'tanggal' => $this->tgl_to_sql($this->input->post('tanggal')),
				'status' => $this->input->post('status'),
				'dept' => $this->input->post('dept'),
				'via' => $this->input->post('via'),
				'dest' => $this->input->post('dest'),
				'date' => $this->tgl_to_sql($this->input->post('date')),
				'time' => $this->input->post('time'),
				'arrive' => $this->input->post('arrive'),
				'flight_no' => $this->input->post('flight_no'),
				'class' => $this->input->post('class'),
				'carrier' => $this->input->post('carrier'),
				'passenger_name' => $this->input->post('passenger_name'),
				'gender' => $this->input->post('gender'),
				'contact_person' => $this->input->post('contact_person'),
				'sale' => $this->input->post('sale'),
				'net' => $this->input->post('net'),
				'nta' => $this->input->post('nta'),
				'pnr' => $this->input->post('pnr'),
				'date_limit' => $this->tgl_to_sql($this->input->post('date_limit')),
				'time_limit' => $this->input->post('time_limit'),
				'agent' => $this->input->post('agent'),
				'ticketing' => $this->input->post('ticketing'),
				'no_ticket' => $this->input->post('no_ticket'),
				'info_tambahan' => $this->input->post('info_tambahan'),
			);
	
        
		
	  	$this->reservasi->update(array('id_reservasi' => $this->input->post('id_reservasi')), $data);
	  	$this->session->set_flashdata('success',' Edit Data Reservasi');
	  	redirect('reservasi');
		}else{
		if ($id == NULL){
			redirect('reservasi');
		}
		$data ['title']	= $this->title;
		$data ['record']= $this->reservasi->get_by_id_md5($id);
		$data['rute'] = $this->reservasi->rute();
	   	$data['carrier'] = $this->reservasi->carrier();
	   	$data['agent'] = $this->reservasi->agent();
	   	$data['ticketing'] = $this->reservasi->ticketing();
		$this->template->load('template',$this->folder.'/edit',$data);	
		}
		
	}

	function detail($id){
		if ($id == NULL){
			redirect('reservasi');
		}
		$data ['title']	= $this->title;
		$data ['record']= $this->reservasi->get_by_id_md5($id);
		$this->template->load('template',$this->folder.'/detail',$data);	
	}

	function upload($id){
		if ($id == NULL){
			redirect('reservasi');
		}
		$data ['title']	= 'Berkas Reservasi';
		$data ['record']= $this->reservasi->get_by_id_md5($id);
		$this->template->load('template',$this->folder.'/upload',$data);	
	}

	function upload_berkas(){
		cek_session_admin();
		if (isset($_POST['submit'])){
		$config['upload_path'] = './assets/img/'; //path folder
        $config['allowed_types'] = 'gif|jpg|png|zip|rar|pdf|doc|docx|ppt|pptx|xls|xlsx|txt'; //type yang dapat diakses bisa anda sesuaikan
        $config['encrypt_name'] = TRUE; //Enkripsi nama yang terupload
 
        $this->upload->initialize($config);
		  if(!empty($_FILES['filefoto']['name'])){
 
            if ($this->upload->do_upload('filefoto')){
                $gbr = $this->upload->data();
                $gambar=$gbr['file_name'];
               	$data = array(
				'id_reservasi' => $this->input->post('id_reservasi'),
				
				'nama_berkas' => $this->input->post('nama_berkas'),
				'nama_file' => $gambar
			);
               	$insert = $this->reservasi->save_berkas($data);
            }
                      
        }
        $this->session->set_flashdata('success',' Tambah Data Reservasi');
	  	redirect('reservasi/upload/'.md5($this->input->post('id_reservasi'))); 
	  	          
       
		}
	}
    		
	function tambah(){
		cek_session_admin();
		if (isset($_POST['submit'])){
		
            $data = array(
				'id_reservasi' => $this->input->post('id_reservasi'),
				'tanggal' => $this->tgl_to_sql($this->input->post('tanggal')),
				'status' => $this->input->post('status'),
				'dept' => $this->input->post('dept'),
				'via' => $this->input->post('via'),
				'dest' => $this->input->post('dest'),
				'date' => $this->tgl_to_sql($this->input->post('date')),
				'time' => $this->input->post('time'),
				'arrive' => $this->input->post('arrive'),
				'flight_no' => $this->input->post('flight_no'),
				'class' => $this->input->post('class'),
				'carrier' => $this->input->post('carrier'),
				'passenger_name' => $this->input->post('passenger_name'),
				'gender' => $this->input->post('gender'),
				'contact_person' => $this->input->post('contact_person'),
				'sale' => $this->input->post('sale'),
				'net' => $this->input->post('net'),
				'nta' => $this->input->post('nta'),
				'pnr' => $this->input->post('pnr'),
				'date_limit' => $this->tgl_to_sql($this->input->post('date_limit')),
				'time_limit' => $this->input->post('time_limit'),
				'agent' => $this->input->post('agent'),
				'ticketing' => $this->input->post('ticketing'),
				'no_ticket' => $this->input->post('no_ticket'),
				'info_tambahan' => $this->input->post('info_tambahan'),
				'id_user' => $this->session->userdata('id'),
			);
                $insert = $this->reservasi->save($data);
        
	  	$this->session->set_flashdata('success',' Tambah Data Reservasi');
	  	redirect('reservasi');
		}else{
		$data ['title']	= $this->title;
	   	$data['kodeunik'] = $this->reservasi->get_no_invoice();
	   	$data['rute'] = $this->reservasi->rute();
	   	$data['carrier'] = $this->reservasi->carrier();
	   	$data['agent'] = $this->reservasi->agent();
	   	$data['ticketing'] = $this->reservasi->ticketing();
		$this->template->load('template',$this->folder.'/tambah',$data);		
		}
	}

	function getdata()
	{
		cek_session_admin();
		$list = $this->reservasi->get_datatables();
		$data = array();
		$no = $_POST['start'];
		
		


		foreach ($list as $field) {
			if ($field->balance == 'Credit'){
				$balance = 'Credit';
			}elseif($field->balance == 'Lunas'){
				$balance = 'Lunas';
			}elseif($field->balance == 'BRI'){
				$balance = 'BRI';
			}else{
				$balance ='BNI';
			}

			//$var= "Gmail is built on the idea ";
			$nama ='';
			$no = 1 ;
			$PecahStr = explode(",", $field->passenger_name);
			foreach($PecahStr as $element)
			{
			$nama .= $no.'. '.$element."<br/>";
			$no++;
			}

	

			$dept = $this->db->query("SELECT * FROM sn_rute WHERE id_rute='".$field->dest."'");
            $dept_tampil = $dept->row_array();
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $field->id_reservasi;
			$row[] = DATE('d-m-Y',strtotime($field->tanggal));
			$row[] = $nama;
			$row[] = DATE('d-m-Y',strtotime($field->date));
			$row[] = $dept_tampil['nama_rute'];
			$row[] = $field->nama_carrier;
			
			$row[] = $balance;
			$row[] = $field->status;
			//add html for action
			$row[] = '
			<a class="btn  btn-xs btn-default" href="'.base_url()."reservasi/edit/".md5($field->id_reservasi).'" title="Edit" ><i class="fa fa-pencil"></i></a>
				 <a class="btn btn-xs btn-success" href="'.base_url()."reservasi/detail/".md5($field->id_reservasi).'"title="Detail" ><i class="glyphicon glyphicon-zoom-in"></i> </a>
				  <a class="btn btn-xs btn-danger" href="javascript:void(0)" title="Hapus" onclick="hapus('."'".$field->id_reservasi."'".')"><i class="glyphicon glyphicon-trash"></i> </a>';

			$data[] = $row;
		}

		$output = array(
			"draw" => $_POST['draw'],
			"recordsTotal" => $this->reservasi->count_all(),
			"recordsFiltered" => $this->reservasi->count_filtered(),
			"data" => $data,
		);
		//output dalam format JSON
		echo json_encode($output);
	}


	public function hapus($id)
	{
		cek_session_admin();
		$this->reservasi->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}

	public function hapus_berkas($id)
	{
		cek_session_admin();
		$data = $this->reservasi->get_by_id($id);
		unlink('assets/img/'.$data->nama_file);
		$this->reservasi->delete_by_id_berkas($id);
		redirect('reservasi/upload/'.md5($data->id_reservasi));
	}


	public function export(){
    include APPPATH.'third_party/PHPExcel/PHPExcel.php';
    

    $excel = new PHPExcel();

    $excel->getProperties()->setCreator('Aplikasi Reservasi')
                 ->setLastModifiedBy('Aplikasi Reservasi')
                 ->setTitle("Data Reservasi")
                 ->setSubject("Reservasi")
                 ->setDescription("Laporan Data reservasi")
                 ->setKeywords("Data Siswa");

    
    $style_col = array(
      'font' => array('bold' => true), 
      'alignment' => array(
        'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, 
        'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER 
      ),
      'borders' => array(
        'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), 
        'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  
        'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), 
        'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) 
      )
    );

    
    $style_row = array(
      'alignment' => array(
        'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER 
      ),
      'borders' => array(
        'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), 
        'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), 
        'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), 
        'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) 
      )
    );

    $excel->setActiveSheetIndex(0)->setCellValue('A1', "DATA RESERVASI"); 
    $excel->getActiveSheet()->mergeCells('A1:AB1'); 
    $excel->getActiveSheet()->getStyle('A1')->getFont()->setBold(TRUE); 
    $excel->getActiveSheet()->getStyle('A1')->getFont()->setSize(15); 
    $excel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT); 

   
    $excel->setActiveSheetIndex(0)->setCellValue('A3', "NO"); 
    $excel->setActiveSheetIndex(0)->setCellValue('B3', "ID RESERVASI"); 
    $excel->setActiveSheetIndex(0)->setCellValue('C3', "TANGGAL"); 
    $excel->setActiveSheetIndex(0)->setCellValue('D3', "STATUS"); 
    $excel->setActiveSheetIndex(0)->setCellValue('E3', "DEPT"); 
    $excel->setActiveSheetIndex(0)->setCellValue('F3', "VIA"); 
    $excel->setActiveSheetIndex(0)->setCellValue('G3', "DEST"); 
    $excel->setActiveSheetIndex(0)->setCellValue('H3', "DATE"); 
    $excel->setActiveSheetIndex(0)->setCellValue('I3', "TIME"); 
    $excel->setActiveSheetIndex(0)->setCellValue('J3', "ARRIVE"); 
    $excel->setActiveSheetIndex(0)->setCellValue('K3', "FLIGH NO."); 
    $excel->setActiveSheetIndex(0)->setCellValue('L3', "CLASS"); 
    $excel->setActiveSheetIndex(0)->setCellValue('M3', "CARRIER"); 
    $excel->setActiveSheetIndex(0)->setCellValue('N3', "PESSANGER NAME"); 
    $excel->setActiveSheetIndex(0)->setCellValue('O3', "GENDER"); 
    $excel->setActiveSheetIndex(0)->setCellValue('P3', "BALANCE"); 
    $excel->setActiveSheetIndex(0)->setCellValue('Q3', "CONTACT PERSON"); 
    $excel->setActiveSheetIndex(0)->setCellValue('R3', "SALE"); 
    $excel->setActiveSheetIndex(0)->setCellValue('S3', "NET"); 
    $excel->setActiveSheetIndex(0)->setCellValue('T3', "NTA"); 
    $excel->setActiveSheetIndex(0)->setCellValue('U3', "PNR"); 
    $excel->setActiveSheetIndex(0)->setCellValue('V3', "DATE LIMIT"); 
    $excel->setActiveSheetIndex(0)->setCellValue('W3', "TIME LIMIT"); 
    $excel->setActiveSheetIndex(0)->setCellValue('X3', "NO. INVOICE"); 
    $excel->setActiveSheetIndex(0)->setCellValue('Y3', "AGENT"); 
    $excel->setActiveSheetIndex(0)->setCellValue('Z3', "TICKETING"); 
    $excel->setActiveSheetIndex(0)->setCellValue('AA3', "NO. TICKET"); 
    $excel->setActiveSheetIndex(0)->setCellValue('AB3', "INFO TAMBAHAN"); 

  
    $excel->getActiveSheet()->getStyle('A3')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('B3')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('C3')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('D3')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('E3')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('F3')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('G3')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('H3')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('I3')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('J3')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('K3')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('L3')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('M3')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('N3')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('O3')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('P3')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('Q3')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('R3')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('S3')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('T3')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('U3')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('V3')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('W3')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('X3')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('Y3')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('Z3')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('AA3')->applyFromArray($style_col);
    $excel->getActiveSheet()->getStyle('AB3')->applyFromArray($style_col);

    
    $reservasi = $this->reservasi->view();

    $no = 1; 
    $numrow = 4; 
    foreach($reservasi as $data){ 
    $dept = $this->db->query("SELECT * FROM sn_rute WHERE id_rute='".$data->dest."'");
    $dept_tampil = $dept->row_array();

    $via = $this->db->query("SELECT * FROM sn_rute WHERE id_rute='".$data->via."'");
    $via_tampil = $via->row_array();

    $dest = $this->db->query("SELECT * FROM sn_rute WHERE id_rute='".$data->dest."'");
    $dest_tampil = $dest->row_array();

    $agent =$this->reservasi->agent_detail($data->agent)->row_array();

    $ticketing =$this->reservasi->ticketing_detail($data->ticketing)->row_array();

    $nama ='';
			$no = 1 ;
			$PecahStr = explode(",", $data->passenger_name);
			foreach($PecahStr as $element)
			{
			$nama .= ' '.$no.'. '.$element;
			$no++;
			}


    if ($data->balance == 'Credit'){
				$balance = 'Credit';
			}elseif($data->balance == 'Lunas'){
				$balance = 'Lunas';
			}elseif($data->balance == 'BRI'){
				$balance = 'BRI';
			}else{
				$balance ='BNI';
			}

      $excel->setActiveSheetIndex(0)->setCellValue('A'.$numrow, $no);
      $excel->setActiveSheetIndex(0)->setCellValue('B'.$numrow, $data->id_reservasi);
      $excel->setActiveSheetIndex(0)->setCellValue('C'.$numrow, DATE('d-m-Y',strtotime($data->tanggal)));
      $excel->setActiveSheetIndex(0)->setCellValue('D'.$numrow, $data->status);
      $excel->setActiveSheetIndex(0)->setCellValue('E'.$numrow, $dept_tampil['nama_rute']);
      $excel->setActiveSheetIndex(0)->setCellValue('F'.$numrow, $via_tampil['nama_rute']);
      $excel->setActiveSheetIndex(0)->setCellValue('G'.$numrow, $dest_tampil['nama_rute']);
      $excel->setActiveSheetIndex(0)->setCellValue('H'.$numrow, DATE('d-m-Y',strtotime($data->date)));
      $excel->setActiveSheetIndex(0)->setCellValue('I'.$numrow, date("g:i A", strtotime($data->time)));
      $excel->setActiveSheetIndex(0)->setCellValue('J'.$numrow, date("g:i A", strtotime($data->arrive)));
      $excel->setActiveSheetIndex(0)->setCellValue('K'.$numrow, $data->flight_no);
      $excel->setActiveSheetIndex(0)->setCellValue('L'.$numrow, $data->class);
      $excel->setActiveSheetIndex(0)->setCellValue('M'.$numrow, $data->nama_carrier);
      $excel->setActiveSheetIndex(0)->setCellValue('N'.$numrow, $nama);
      $excel->setActiveSheetIndex(0)->setCellValue('O'.$numrow, $data->gender);
      $excel->setActiveSheetIndex(0)->setCellValue('P'.$numrow, $balance);
      $excel->setActiveSheetIndex(0)->setCellValue('Q'.$numrow, $data->contact_person);
      $excel->setActiveSheetIndex(0)->setCellValue('R'.$numrow, $data->sale);
      $excel->setActiveSheetIndex(0)->setCellValue('S'.$numrow, $data->net);
      $excel->setActiveSheetIndex(0)->setCellValue('T'.$numrow, $data->nta);
      $excel->setActiveSheetIndex(0)->setCellValue('U'.$numrow, $data->pnr);
      $excel->setActiveSheetIndex(0)->setCellValue('V'.$numrow, DATE('d-m-Y',strtotime($data->date_limit)));
      $excel->setActiveSheetIndex(0)->setCellValue('W'.$numrow, date("g:i A", strtotime($data->time_limit)));
      $excel->setActiveSheetIndex(0)->setCellValue('X'.$numrow, $data->no_invoice);
      $excel->setActiveSheetIndex(0)->setCellValue('Y'.$numrow, $agent['nama_agent']);
      $excel->setActiveSheetIndex(0)->setCellValue('Z'.$numrow, $ticketing['nama_ticketing']);
      $excel->setActiveSheetIndex(0)->setCellValue('AA'.$numrow, $data->no_ticket);
      $excel->setActiveSheetIndex(0)->setCellValue('AB'.$numrow, $data->info_tambahan);


      
      $excel->getActiveSheet()->getStyle('A'.$numrow)->applyFromArray($style_row);
      $excel->getActiveSheet()->getStyle('B'.$numrow)->applyFromArray($style_row);
      $excel->getActiveSheet()->getStyle('C'.$numrow)->applyFromArray($style_row);
      $excel->getActiveSheet()->getStyle('D'.$numrow)->applyFromArray($style_row);
      $excel->getActiveSheet()->getStyle('E'.$numrow)->applyFromArray($style_row);
      $excel->getActiveSheet()->getStyle('F'.$numrow)->applyFromArray($style_row);
      $excel->getActiveSheet()->getStyle('G'.$numrow)->applyFromArray($style_row);
      $excel->getActiveSheet()->getStyle('H'.$numrow)->applyFromArray($style_row);
      $excel->getActiveSheet()->getStyle('I'.$numrow)->applyFromArray($style_row);
      $excel->getActiveSheet()->getStyle('J'.$numrow)->applyFromArray($style_row);
      $excel->getActiveSheet()->getStyle('K'.$numrow)->applyFromArray($style_row);
      $excel->getActiveSheet()->getStyle('L'.$numrow)->applyFromArray($style_row);
      $excel->getActiveSheet()->getStyle('M'.$numrow)->applyFromArray($style_row);
      $excel->getActiveSheet()->getStyle('N'.$numrow)->applyFromArray($style_row);
      $excel->getActiveSheet()->getStyle('O'.$numrow)->applyFromArray($style_row);
      $excel->getActiveSheet()->getStyle('P'.$numrow)->applyFromArray($style_row);
      $excel->getActiveSheet()->getStyle('Q'.$numrow)->applyFromArray($style_row);
      $excel->getActiveSheet()->getStyle('R'.$numrow)->applyFromArray($style_row);
      $excel->getActiveSheet()->getStyle('S'.$numrow)->applyFromArray($style_row);
      $excel->getActiveSheet()->getStyle('T'.$numrow)->applyFromArray($style_row);
      $excel->getActiveSheet()->getStyle('U'.$numrow)->applyFromArray($style_row);
      $excel->getActiveSheet()->getStyle('V'.$numrow)->applyFromArray($style_row);
      $excel->getActiveSheet()->getStyle('W'.$numrow)->applyFromArray($style_row);
      $excel->getActiveSheet()->getStyle('X'.$numrow)->applyFromArray($style_row);
      $excel->getActiveSheet()->getStyle('Y'.$numrow)->applyFromArray($style_row);
      $excel->getActiveSheet()->getStyle('Z'.$numrow)->applyFromArray($style_row);
      $excel->getActiveSheet()->getStyle('AA'.$numrow)->applyFromArray($style_row);
      $excel->getActiveSheet()->getStyle('AB'.$numrow)->applyFromArray($style_row);
      
      $no++; 
      $numrow++; 
    }

    
    $excel->getActiveSheet()->getColumnDimension('A')->setWidth(5); 
    $excel->getActiveSheet()->getColumnDimension('B')->setWidth(15); 
    $excel->getActiveSheet()->getColumnDimension('C')->setWidth(15); 
    $excel->getActiveSheet()->getColumnDimension('D')->setWidth(15); 
    $excel->getActiveSheet()->getColumnDimension('E')->setWidth(20); 
    $excel->getActiveSheet()->getColumnDimension('F')->setWidth(30); 
    $excel->getActiveSheet()->getColumnDimension('G')->setWidth(30); 
    $excel->getActiveSheet()->getColumnDimension('H')->setWidth(10);
    $excel->getActiveSheet()->getColumnDimension('I')->setWidth(10); 
    $excel->getActiveSheet()->getColumnDimension('J')->setWidth(10); 
    $excel->getActiveSheet()->getColumnDimension('K')->setWidth(10); 
    $excel->getActiveSheet()->getColumnDimension('L')->setWidth(10); 
    $excel->getActiveSheet()->getColumnDimension('M')->setWidth(10); 
    $excel->getActiveSheet()->getColumnDimension('N')->setWidth(30); 
    $excel->getActiveSheet()->getColumnDimension('O')->setWidth(10); 
    $excel->getActiveSheet()->getColumnDimension('P')->setWidth(10); 
    $excel->getActiveSheet()->getColumnDimension('Q')->setWidth(20); 
    $excel->getActiveSheet()->getColumnDimension('R')->setWidth(15); 
    $excel->getActiveSheet()->getColumnDimension('S')->setWidth(15); 
    $excel->getActiveSheet()->getColumnDimension('T')->setWidth(15); 
    $excel->getActiveSheet()->getColumnDimension('U')->setWidth(15); 
    $excel->getActiveSheet()->getColumnDimension('V')->setWidth(15); 
    $excel->getActiveSheet()->getColumnDimension('W')->setWidth(15); 
    $excel->getActiveSheet()->getColumnDimension('X')->setWidth(15); 
    $excel->getActiveSheet()->getColumnDimension('Y')->setWidth(15); 
    $excel->getActiveSheet()->getColumnDimension('Z')->setWidth(15); 
    $excel->getActiveSheet()->getColumnDimension('AA')->setWidth(15); 
    $excel->getActiveSheet()->getColumnDimension('AB')->setWidth(30); 
    
    
    $excel->getActiveSheet()->getDefaultRowDimension()->setRowHeight(-1);

    
    $excel->getActiveSheet()->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);

    
    $excel->getActiveSheet(0)->setTitle("Laporan Data Reservasi");
    $excel->setActiveSheetIndex(0);

    
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="Data_Reservasi_'.DATE('d-m-Y').'.xlsx"'); 
    header('Cache-Control: max-age=0');

    $write = PHPExcel_IOFactory::createWriter($excel, 'Excel2007');
    $write->save('php://output');
  }



}
