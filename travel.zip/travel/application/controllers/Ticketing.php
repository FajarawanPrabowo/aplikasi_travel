<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ticketing extends CI_Controller {
	
	var $folder =   "main/ticketing";
    var $title  =   "Data ticketing";

	function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('Model_ticketing','ticketing');
	}

	function index(){
		cek_session_admin();
		
	   	$data ['title']	= $this->title;	   	
		$this->template->load('template',$this->folder.'/ticketing',$data);
	}

	function tgl_to_sql($date){
	$exp = explode('-',$date);
		if(count($exp) == 3) {
			$date = $exp[2].'-'.$exp[1].'-'.$exp[0];
		}
		return $date;
	}

	function edit($id = NULL){
		cek_session_admin();
		if (isset($_POST['submit'])){
		$data = array(
				'nama_ticketing' => $this->input->post('nama_ticketing'),
				'aktif' => $this->input->post('aktif'),
			);

	  	$this->ticketing->update(array('id_ticketing' => $this->input->post('id_ticketing')), $data);
	  	$this->session->set_flashdata('success',' Edit Data Ticketing');
	  	redirect('ticketing');
		}else{
		if ($id == NULL){
			redirect('ticketing');
		}
		$data ['title']	= $this->title;
		$data ['record']= $this->ticketing->get_by_id_md5($id);
		$this->template->load('template',$this->folder.'/edit',$data);	
		}
		
	}

	function detail($id){
		if ($id == NULL){
			redirect('reservasi');
		}
		$data ['title']	= $this->title;
		$data ['record']= $this->reservasi->get_by_id_md5($id);
		$this->template->load('template',$this->folder.'/detail',$data);	
	}

	function tambah(){
		cek_session_admin();
		if (isset($_POST['submit'])){
	   	$data = array(
				'nama_ticketing' => $this->input->post('nama_ticketing')
			);

	  	$insert = $this->ticketing->save($data);
	  	$this->session->set_flashdata('success',' Tambah Data Ticketing');
	  	redirect('ticketing');
		}else{
		$data ['title']	= $this->title;
		$this->template->load('template',$this->folder.'/tambah',$data);		
		}
	}

	function getdata()
	{
		cek_session_admin();
		$list = $this->ticketing->get_datatables();
		$data = array();
		$no = $_POST['start'];
		
		foreach ($list as $field) {
			
			$no++;
			$row = array();
			$row[] = $no;
			$row[] = $field->nama_ticketing;
			$row[] = $field->aktif;
			//add html for action
			$row[] = '<a class="btn  btn-xs btn-default" href="'.base_url()."ticketing/edit/".md5($field->id_ticketing).'" title="Edit" ><i class="fa fa-pencil"></i></a>
				  <a class="btn btn-xs btn-danger" href="javascript:void(0)" title="Hapus" onclick="hapus('."'".$field->id_ticketing."'".')"><i class="glyphicon glyphicon-trash"></i> </a>';

			$data[] = $row;
		}

		$output = array(
			"draw" => $_POST['draw'],
			"recordsTotal" => $this->ticketing->count_all(),
			"recordsFiltered" => $this->ticketing->count_filtered(),
			"data" => $data,
		);
		//output dalam format JSON
		echo json_encode($output);
	}


	public function hapus($id)
	{
		cek_session_admin();
		$this->ticketing->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}



}
