<?php 
    function cek_session_admin(){
        $ci = & get_instance();
        $session = $ci->session->userdata('status');
        if ($session == ''){
            redirect(base_url().'login');
        }
    }

    function cek_session_user(){
        $ci = & get_instance();
        $session = $ci->session->userdata('level');
        if ($session == 'user'){
            redirect(base_url().'login');
        }
    }


function encrypt($str) {
    $hasil = '';
    $kunci = 'terusbelajaruntukmenggapaicitacitajanganlupaberdoa123';
    for ($i = 0; $i < strlen($str); $i++) {
        $karakter = substr($str, $i, 1);
        $kuncikarakter = substr($kunci, ($i % strlen($kunci))-1, 1);
        $karakter = chr(ord($karakter)+ord($kuncikarakter));
        $hasil .= $karakter;
        
    }
    return urlencode(base64_encode($hasil));
}

function decrypt($str) {
    $str = base64_decode(urldecode($str));
    $hasil = '';
    $kunci = 'terusbelajaruntukmenggapaicitacitajanganlupaberdoa123';
    for ($i = 0; $i < strlen($str); $i++) {
        $karakter = substr($str, $i, 1);
        $kuncikarakter = substr($kunci, ($i % strlen($kunci))-1, 1);
        $karakter = chr(ord($karakter)-ord($kuncikarakter));
        $hasil .= $karakter;
        
    }
    return $hasil;
}