<?php

class Model_invoice extends CI_Model {

	var $table = 'sn_invoice'; //nama tabel dari database
	var $column_order = array(null, 'sn_invoice.id_invoice','sn_invoice.passenger','sn_invoice.tanggal_invoice','sn_invoice.tanggal_tempo','sn_invoice.status_invoice'); //field yang ada di table user
	var $column_search = array('sn_invoice.id_invoice','sn_invoice.passenger','sn_invoice.tanggal_invoice','sn_invoice.tanggal_tempo','sn_invoice.status_invoice'); //field yang diizin untuk pencarian 
	var $order = array('sn_invoice.id_invoice' => 'asc'); // default order 

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	private function _get_datatables_query()
	{
		
		$this->db->from($this->table);

		$i = 0;
	
		foreach ($this->column_search as $item) // loop column 
		{
			if($_POST['search']['value']) // if datatable send POST for search
			{
				
				if($i===0) // first loop
				{
					$this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
					$this->db->like($item, $_POST['search']['value']);
				}
				else
				{
					$this->db->or_like($item, $_POST['search']['value']);
				}

				if(count($this->column_search) - 1 == $i) //last loop
					$this->db->group_end(); //close bracket
			}
			$i++;
		}
		
		if(isset($_POST['order'])) // here order processing
		{
			$this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
		} 
		else if(isset($this->order))
		{
			$order = $this->order;
			$this->db->order_by(key($order), $order[key($order)]);
		}
	}

	function get_datatables()
	{
		$this->_get_datatables_query();
		if($_POST['length'] != -1)
		$this->db->limit($_POST['length'], $_POST['start']);
		//if ($this->session->userdata('level') == 'user') {
		//	$this->db->where('sn_invoice.id_user',$this->session->userdata('id'));
		//}
		$query = $this->db->get();
		return $query->result();
	}

	function count_filtered()
	{
		$this->_get_datatables_query();
		//if ($this->session->userdata('level') == 'user') {
		//	$this->db->where('sn_invoice.id_user',$this->session->userdata('id'));
		//}
		$query = $this->db->get();
		return $query->num_rows();
	}


	public function omset_status($tgl_awal,$tgl_akhir,$status){
      $this->db->from($this->table);
      $this->db->where('tanggal_invoice >=',$tgl_awal);
      $this->db->where('tanggal_invoice <=',$tgl_akhir);
      $this->db->where('status_invoice',$status);
      return  $this->db->get();
    }

    public function omset_no_status($tgl_awal,$tgl_akhir){
      $this->db->from($this->table);
      $this->db->where('tanggal_invoice >=',$tgl_awal);
      $this->db->where('tanggal_invoice <=',$tgl_akhir);
      return  $this->db->get();
    }

	public function count_all()
	{
		$this->db->from($this->table);
		if ($this->session->userdata('level') == 'user') {
			$this->db->where('sn_invoice.id_user',$this->session->userdata('id'));
		}
		return $this->db->count_all_results();
	}

	function tgl_to_sql($date){
		$exp = explode('-',$date);
		if(count($exp) == 3) {
			$date = $exp[2].'-'.$exp[1].'-'.$exp[0];
		}
		return $date;
	}

	public function save()
	{
		

		$config['upload_path'] = './assets/img/'; //path folder
        $config['allowed_types'] = 'gif|jpg|png|jpeg|bmp'; //type yang dapat diakses bisa anda sesuaikan
        $config['encrypt_name'] = TRUE; //Enkripsi nama yang terupload

        $this->upload->initialize($config);
        if(!empty($_FILES['filefoto']['name'])){

        	if ($this->upload->do_upload('filefoto')){
        		$gbr = $this->upload->data();
                //Compress Image
        		$config['image_library']='gd2';
        		$config['source_image']='./assets/img/'.$gbr['file_name'];
        		$config['create_thumb']= FALSE;
        		$config['maintain_ratio']= FALSE;
        		$config['quality']= '50%';
        		$config['new_image']= './assets/img/'.$gbr['file_name'];
        		$this->load->library('image_lib', $config);
        		$this->image_lib->resize();

        		$gambar=$gbr['file_name'];
            $data = array('id_invoice' => $this->input->post('id_invoice'),
        		'passenger' => $this->input->post('passenger'),
        		'status_invoice' => $this->input->post('status'),
        		'tanggal_invoice' => $this->tgl_to_sql($this->input->post('tanggal')),
        		'tanggal_tempo' => $this->tgl_to_sql($this->input->post('tanggal_tempo')),
        		'info' => $this->input->post('info'),
        			'gambar'=>$gambar,);
        		 //$insert = $this->invoice->save($data);

        	  // $this->session->set_flashdata('success',' Tambah Invoice');
            $this->db->insert($this->table, $data);
		    return $this->db->insert_id();

        	}

        }else{

        	$data = array(
        		'id_invoice' => $this->input->post('id_invoice'),
        		'passenger' => $this->input->post('passenger'),
        		'status_invoice' => $this->input->post('status'),
        		'tanggal_invoice' => $this->tgl_to_sql($this->input->post('tanggal')),
        		'tanggal_tempo' => $this->tgl_to_sql($this->input->post('tanggal_tempo')),
        		'info' => $this->input->post('info'),
        	);

        	//$insert = $this->invoice->save($data);

        	//$this->session->set_flashdata('success',' Tambah Invoice');
        	//redirect('invoice');
        	$this->db->insert($this->table, $data);
			return $this->db->insert_id();
        }




		
	}



	public function ubah()
	{
		$config['upload_path'] = './assets/img/'; //path folder
        $config['allowed_types'] = 'gif|jpg|png|jpeg|bmp'; //type yang dapat diakses bisa anda sesuaikan
        $config['encrypt_name'] = TRUE; //Enkripsi nama yang terupload

        $this->upload->initialize($config);
        if(!empty($_FILES['filefoto']['name'])){

        	if ($this->upload->do_upload('filefoto')){
        		$gbr = $this->upload->data();
                //Compress Image
        		$config['image_library']='gd2';
        		$config['source_image']='./assets/img/'.$gbr['file_name'];
        		$config['create_thumb']= FALSE;
        		$config['maintain_ratio']= FALSE;
        		$config['quality']= '50%';
        		$config['new_image']= './assets/img/'.$gbr['file_name'];
        		$this->load->library('image_lib', $config);
        		$this->image_lib->resize();

        		$gambar=$gbr['file_name'];
        		$id = $this->input->post('id_invoice');
        		$row = $this->db->query("SELECT gambar FROM sn_invoice WHERE id_invoice='$id'")->row_array();
        		unlink('./assets/img/'.$row['gambar']);

        		$data = array(
        			'id_invoice' => $this->input->post('id_invoice'),
        			'passenger' => $this->input->post('passenger'),
        			'status_invoice' => $this->input->post('status'),
        			'tanggal_invoice' => $this->tgl_to_sql($this->input->post('tanggal')),
        			'tanggal_tempo' => $this->tgl_to_sql($this->input->post('tanggal_tempo')),
        			'info' => $this->input->post('info'),
        			'gambar'=>$gambar,
        		);


        		$id_reservasi = $this->input->post('id_reservasi');
        		$jumlah = $this->input->post('jumlah');
        		$id = $this->input->post('id_detail_invoice');
        		$cpt = count($_POST['id_reservasi']);
        		for ($i = 0; $i < $cpt; $i++) {
        			$param['id_invoice'] = $this->input->post('id_invoice');
        			$param['id_reservasi'] = $id_reservasi[$i];
        			$param['jumlah'] = $jumlah[$i];


        			$this->invoice->update_reservasi(array('id_detail_invoice' => $id[$i]), $param);
        			$data_reservasi = array('balance' => $this->input->post('status'));
        			$this->reservasi->update(array('id_reservasi' => $id_reservasi[$i]), $data_reservasi);

        		}

        		$this->invoice->update(array('id_invoice' => $this->input->post('id_invoice')), $data);


        	}

        }else{



        	$data = array(
        		'id_invoice' => $this->input->post('id_invoice'),
        		'passenger' => $this->input->post('passenger'),
        		'status_invoice' => $this->input->post('status'),
        		'tanggal_invoice' => $this->tgl_to_sql($this->input->post('tanggal')),
        		'tanggal_tempo' => $this->tgl_to_sql($this->input->post('tanggal_tempo')),
        		'info' => $this->input->post('info'),
        	);

        	$id_reservasi = $this->input->post('id_reservasi');
        	$jumlah = $this->input->post('jumlah');
        	$id = $this->input->post('id_detail_invoice');
        	$cpt = count($_POST['id_reservasi']);
        	for ($i = 0; $i < $cpt; $i++) {
        		$param['id_invoice'] = $this->input->post('id_invoice');
        		$param['id_reservasi'] = $id_reservasi[$i];
        		$param['jumlah'] = $jumlah[$i];


        		$this->invoice->update_reservasi(array('id_detail_invoice' => $id[$i]), $param);
        		$data_reservasi = array('balance' => $this->input->post('status'));
        		$this->reservasi->update(array('id_reservasi' => $id_reservasi[$i]), $data_reservasi);

        	}
        	$this->invoice->update(array('id_invoice' => $this->input->post('id_invoice')), $data);

        	



        }
	}

	public function save2($data)
	{
		$this->db->insert($this->table, $data);
		return $this->db->insert_id();
	}

	public function save_reservasi($data)
	{
		$this->db->insert('detail_invoice', $data);
		return $this->db->insert_id();
	}

	function reservasi_edit(){
        return $this->db->query("SELECT * FROM sn_reservasi WHERE id_user='".($this->session->userdata('id'))."'");
    }

    function jumlah_reservasi($id){
    	return $this->db->query("SELECT SUM(jumlah) as jml FROM detail_invoice WHERE id_invoice='$id'");
    }

    function detail_reservasi($id){
    	return $this->db->query("SELECT * FROM detail_invoice WHERE id_invoice='$id' ");
    }

    function reservasi(){
        return $this->db->query("SELECT * FROM sn_reservasi WHERE NOT EXISTS (SELECT * FROM detail_invoice WHERE detail_invoice.id_reservasi = sn_reservasi.id_reservasi) AND id_user='".($this->session->userdata('id'))."'");
    }



	function get_no_invoice(){
		$q = $this->db->query("SELECT MAX(RIGHT(id_invoice,4)) AS kd_max FROM sn_invoice ");
        $kd = "";
        if($q->num_rows()>0){
            foreach($q->result() as $k){
                $tmp = ((int)$k->kd_max)+1;
                $kd = sprintf("%04s", $tmp);
            }
        }else{
            $kd = "0001";
        }
        date_default_timezone_set('Asia/Jakarta');
        return "INV-".$kd;
	}


	public function get_by_id_md5($id)
	{

		$this->db->where('md5(sn_invoice.id_invoice)',$id);
		$sql_query = $this->db->get($this->table);
		$this->db->join('detail_invoice', 'detail_invoice.id_invoice = sn_invoice.id_invoice', 'left');
		if ($sql_query->num_rows() == 1){
			return $sql_query->row_array();
		}
	}



	public function get_detail_by_id_md5($id)
	{

		$this->db->where('md5(id_detail_invoice)',$id);
		$sql_query = $this->db->get('detail_invoice');

		if ($sql_query->num_rows() == 1){
			return $sql_query->row_array();
		}
	}

	public function hapus_by_id_md5($id)
	{

		//$idd = $this->db->where('md5(id_invoice)',$id);;
        $row = $this->db->query("SELECT gambar FROM sn_invoice WHERE md5(id_invoice)='$id'")->row_array();
        if ($row['gambar']) {
        	unlink('./assets/img/'.$row['gambar']);
        }
		

		$this->db->where('md5(id_invoice)',$id);
		$this->db->delete($this->table);
	}

	public function hapus_detail_by_id_md5($id)
	{

		$this->db->where('md5(id_detail_invoice)',$id);
		$this->db->delete('detail_invoice');
	}

	function get_by_id($id){
        return $this->db->query("SELECT * FROM sn_invoice WHERE id_invoice='$id' ");
    }


	public function update($where, $data)
	{
		$this->db->update($this->table, $data, $where);
		return $this->db->affected_rows();
	}

	public function update_reservasi($where, $data)
	{
		$this->db->update('detail_invoice', $data, $where);
		return $this->db->affected_rows();
	}

	public function delete_by_id($id)
	{
		$this->db->where('id_invoice', $id);
		$this->db->delete($this->table);
	}

	public function join_detail($id){
		return $this->db->query("SELECT * FROM  sn_reservasi WHERE id_reservasi='$id' ");
	}

	function cek_data($data){
		return $this->db->query("SELECT * FROM detail_invoice where id_invoice='$data'");
	}

	public function view(){ 
  	if ($this->session->userdata('level') == 'user') {
			$this->db->where('sn_invoice.id_user',$this->session->userdata('id'));
		}
   return $this->db->get('sn_invoice')->result(); 
  }

	

}
