<?php 
class Model_login extends CI_model{


	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	function cek_admin($username, $password){
		return $this->db->query("SELECT * FROM sn_users where username='".$this->db->escape_str($username)."' AND password='".$this->db->escape_str($password)."'");
	}

	function cek_akun($username, $password){
		return $this->db->query("SELECT * FROM sn_akun where npsn='".$this->db->escape_str($username)."' AND password='".$this->db->escape_str($password)."'");
	}

	function cek_tahun(){
		return $this->db->query("SELECT * FROM sn_tahun where aktif='Y'");
	}


}
