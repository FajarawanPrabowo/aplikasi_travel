<?php

class Model_pencarian extends CI_Model {

	public function pencarian($dept,$dest,$date){
      $this->db->from('sn_reservasi');
      $this->db->join('sn_rute', 'sn_rute.id_rute = sn_reservasi.dept', 'left');
	  $this->db->join('sn_carrier', 'sn_carrier.id_carrier = sn_reservasi.carrier', 'left');
      $this->db->where('dept',$dept);
      $this->db->where('dest',$dest);
      $this->db->where('date',$date);
      return  $this->db->get();
    }
}
