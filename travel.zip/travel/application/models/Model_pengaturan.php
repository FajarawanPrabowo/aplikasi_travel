<?php

class Model_pengaturan extends CI_Model {

	 function pengaturan(){
    	$config['upload_path'] = './assets/img/'; //path folder
        $config['allowed_types'] = 'gif|jpg|png|jpeg|bmp'; //type yang dapat diakses bisa anda sesuaikan
        $config['encrypt_name'] = TRUE; //Enkripsi nama yang terupload
 
        $this->upload->initialize($config);
         if(!empty($_FILES['filefoto']['name'])){
 
            if ($this->upload->do_upload('filefoto')){
                $gbr = $this->upload->data();
                //Compress Image
                $config['image_library']='gd2';
                $config['source_image']='./assets/img/'.$gbr['file_name'];
                $config['create_thumb']= FALSE;
                $config['maintain_ratio']= FALSE;
                $config['quality']= '50%';
                $config['width']= 900;
                $config['height']= 300;
                $config['new_image']= './assets/img/'.$gbr['file_name'];
                $this->load->library('image_lib', $config);
                $this->image_lib->resize();
 
                $gambar=$gbr['file_name'];
                $id = $this->input->post('id');
                $row = $this->db->query("SELECT gambar FROM sn_pengaturan Limit 1")->row_array();
				unlink('./assets/img/'.$row['gambar']);

                $data = array('instansi'=>$this->db->escape_str($this->input->post('instansi')),
                        'alamat'=>$this->db->escape_str($this->input->post('alamat')),
    					'kota'=>$this->db->escape_str($this->input->post('kota')),
    					'telpon'=>$this->db->escape_str($this->input->post('telpon')),
    					'gambar'=>$gambar,);
                $this->db->where('id_pengaturan',1);
				$this->db->update('sn_pengaturan',$data);


            }
                      
        }else{
            $data = array('instansi'=>$this->db->escape_str($this->input->post('instansi')),
                'kota'=>$this->db->escape_str($this->input->post('kota')),
    					'alamat'=>$this->db->escape_str($this->input->post('alamat')),
    					'telpon'=>$this->db->escape_str($this->input->post('telpon')));
            $this->db->where('id_pengaturan',1);
			$this->db->update('sn_pengaturan',$data);
        }

    }

    function get_pengaturan(){
        return $this->db->query("SELECT * FROM sn_pengaturan LIMIT 1");
    }

}
