<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <small>Hallo, <?php echo $this->session->userdata('nama_lengkap');?></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
    
      <div class="row">
        <div class="col-xs-12">
          
          <div class="box" style="padding-top: 30px;padding-bottom: 40px;">
           
            <div class="box-body" >
              <div class="table-responsive text-center">
               <h3>Selamat Datang Di NISA</h3>
               <img width="50%" src="<?php echo base_url();?>assets/img/<?php echo $record['gambar'];?>"><br><br>
               <p>Office : <?php echo $record['alamat'];?></p>
               <p>Telpon : <?php echo $record['telpon'];?></p>
              </div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->