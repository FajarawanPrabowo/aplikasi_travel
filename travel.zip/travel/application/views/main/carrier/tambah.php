 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <small>Selamat datang, <?php echo $this->session->userdata('nama_lengkap');?></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url();?>"><i class="fa fa-dashboard"></i> Beranda</a></li>
        <li class="active"><?php echo $title;?></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
    
      <div class="row">
        <div class="col-xs-12">
          
          <div class="box">
            <div class="box-header" style="background: #fbfbfb;">
              <h3 class="box-title" style="margin-top: 5px;">Data Kendaraan</h3>
              <div class="block-options pull-right">
                 <a class="btn btn-danger btn-sm" href="<?php echo base_url();?>carrier" ><i class="fa fa-undo"></i> Kembali</a>
                
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table class="table table-bordered table-striped" border="0" cellspacing="0" width="100%">
                    <thead>
                        <tr style="background-color: #00a65a ; color: #fff; text-transform: uppercase;">
                            <th  class="text-center">Tambah <?php echo $title;?></th>
                        </tr>
                    </thead>
              </table><br>
  

              <form action="<?php echo base_url();?>carrier/tambah" method="POST">
                <div class="col-sm-12 btn-xs-12">
                <div class="form-group">
                  <label>Nama Kendaraan</label>
                  <input type="text" class="form-control" autofocus name="nama_carrier" >
                </div>
                
               
              </div>


              
            </div>
            <!-- /.box-body -->
            <div class="box-footer">
                <button type="submit" name="submit" class="btn btn-success btn-sm col-md-offset-10"><i class="glyphicon glyphicon-ok"></i> Submit</button>
                <button type="button" class="btn btn-danger btn-sm" href="<?php echo base_url();?>carrier"><i class="glyphicon glyphicon-remove"></i> Kembali</button>
              </div>
            </form>
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

