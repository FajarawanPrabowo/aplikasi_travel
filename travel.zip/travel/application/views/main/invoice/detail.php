 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <small>Selamat datang, <?php echo $this->session->userdata('nama_lengkap');?></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo base_url();?>"><i class="fa fa-dashboard"></i> Beranda</a></li>
        <li class="active"><?php echo $title;?></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
    
      <div class="row">
        <div class="col-xs-12">
          
          <div class="box">
            <div class="box-header" style="background: #fbfbfb;">
              <h3 class="box-title" style="margin-top: 5px;"><?php echo $title;?></h3>
              <div class="block-options pull-right">
                 <a class="btn btn-danger btn-sm" href="<?php echo base_url();?>invoice" ><i class="fa fa-undo"></i> Kembali</a>
                
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table class="table table-bordered table-striped" border="0" cellspacing="0" width="100%">
                    <thead>
                        <tr style="background-color: #e1e1e1 ; color: #6b6c6b; text-transform: uppercase;">
                            <th  class="text-center">Detail <?php echo $title;?></th>
                        </tr>
                    </thead>
              </table><br>
              <div class="col-md-6">
              <table class="table table-bordered" border="0" cellspacing="0" width="100%">
                    <tr>
                      <th width="200">ID. Reservasi</th>
                      <td><?php echo $record['id_reservasi'];?></td>
                    </tr>
                    <tr>
                      <th>Tanggal</th>
                      <td><?php echo DATE('d-m-Y',strtotime($record['tanggal']));?></td>
                    </tr>
                    <tr>
                      <th>Status</th>
                      <td><?php echo $record['status'];?></td>
                    </tr>
                    <tr>
                      <th>Dept.</th>
                      <td><?php echo $record['dept'];?></td>
                    </tr>
                    <tr>
                      <th>Via</th>
                      <td><?php echo $record['via'];?></td>
                    </tr>
                    <tr>
                      <th>Dest</th>
                      <td><?php echo $record['dest'];?></td>
                    </tr>
                    <tr>
                      <th>Date</th>
                      <td><?php echo DATE('d-m-Y',strtotime($record['date']));?></td>
                    </tr>
                    <tr>
                      <th>Time</th>
                      <td><?php echo date("g:i A", strtotime($record['time']));?></td>
                    </tr>
                    <tr>
                      <th>Arrive</th>
                      <td><?php echo date("g:i A", strtotime($record['arrive']));?></td>
                    </tr>
                    <tr>
                      <th>Flight No.</th>
                      <td><?php echo $record['flight_no'];?></td>
                    </tr>
                    <tr>
                      <th>Class</th>
                      <td><?php echo $record['class'];?></td>
                    </tr>
                    <tr>
                      <th>Passenger Name</th>
                      <td><?php echo $record['passenger_name'];?></td>
                    </tr>
                    <tr>
                      <th>Gender</th>
                      <td><?php echo $record['gender'];?></td>
                    </tr>
              </table><br>
              </div>

               <div class="col-md-6">
              <table class="table table-bordered" border="0" cellspacing="0" width="100%">
                    <tr style="background-color: #00a65a;text-transform: uppercase;color: #fff;text-align: center;">
                      <th width="200">Balance</th>
                      <td><?php echo $record['balance'];?></td>
                    </tr>
                    <tr>
                      <th width="200">Contact Person</th>
                      <td><?php echo $record['contact_person'];?></td>
                    </tr>
                    <tr>
                      <th>Sale</th>
                      <td>Rp. <?php echo number_format($record['sale'], 0 ,'.','.');?></td>
                    </tr>
                    <tr>
                      <th>NET</th>
                      <td>Rp. <?php echo number_format($record['net'], 0 ,'.','.');?></td>
                    </tr>
                    <tr>
                      <th>NTA</th>
                      <td>Rp. <?php echo number_format($record['nta'], 0 ,'.','.');?></td>
                    </tr>
                    <tr>
                      <th>PNR</th>
                      <td><?php echo $record['pnr'];?></td>
                    </tr>
                    <tr>
                      <th>Date Limit</th>
                      <td><?php echo DATE('d-m-Y',strtotime($record['date_limit']));?></td>
                    </tr>
                    <tr>
                      <th>Time Limit</th>
                      <td><?php echo date("g:i A", strtotime($record['time_limit']));?></td>
                    </tr>
                    <tr>
                      <th>No. Resi</th>
                      <td><?php echo $record['no_resi'];?></td>
                    </tr>
                    <tr>
                      <th>Agent</th>
                      <td><?php echo $record['agent'];?></td>
                    </tr>
                    <tr>
                      <th>Ticketing.</th>
                      <td><?php echo $record['ticketing'];?></td>
                    </tr>
                    <tr>
                      <th>No. Ticket</th>
                      <td><?php echo $record['no_ticket'];?></td>
                    </tr>
                    <tr>
                      <th>Info Tambahan</th>
                      <td><?php echo $record['info_tambahan'];?></td>
                    </tr>
              </table><br>
              </div>

            </div>
            
           </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

